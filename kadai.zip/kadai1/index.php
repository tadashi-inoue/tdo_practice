<!DOCTYPE HTML>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet href=style.css">
    <title></title>
  </head>
  <body>
    <form action="send.php" method="post">
    <p>URLを入れると、titleタグを生成できます</p>
    <input type="text" name="url">
    <input type="submit" value="生成">
  </body>
</html>
