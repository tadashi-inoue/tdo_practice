<!DOCTYPE HTML>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet href=style.css">
    <title></title>
  </head>
  <body>
    <form action="send.php" method="post">
    <p>SoVaのwebサイトで、閲覧したいページの名前を入れてください</p>
    <input type="text" name="name">
    <input type="submit" value="移動">
  </body>
</html>
