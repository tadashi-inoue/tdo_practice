<!DOCTYPE HTML>
<html lang="ja" prefix="og: http://ogp.me/ns#">
<head>
  <meta charset="utf-8">
  <title>IDEMAE</title>
  <link rel="shortcut icon" type="image/x-icon" href="static/favicon.ico">
  <meta name="viewport" content="width=device-width">
  <!---
  <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0">
  --->
  <meta name="description" content="">
  <meta name="keyword
  s" content="">
  <meta name="author" content="">
  <meta property="og:title" content="IDEMAE">
  <meta property="og:type" content="">
  <meta property="og:description" content="">
  <meta property="og:url" content="">
  <meta property="og:site_name" content="IDEMAE">
  <meta property="og:image" content="static/ogp.png">
  <link href="static/css/reset.css" rel="stylesheet" type="text/css" media="all" />
  <link href="static/css/style.css" rel="stylesheet" type="text/css" media="all" />
  <link rel="apple-touch-icon" href="static/webclip.png">
  <script type="text/javascript" src="static/js/jquery-3.3.1.min.js"></script>
</head>
<body>
  <header>
    <?php require_once('header.html'); ?>
  </header>
  <main>
    <section class="fv">
      <div class="common_wrap">
        <div class="common_inner">
          <div class="fv_content">
            <div class="fv_content_detail">
              <div class="fv_sub_text_wrap">
                <p class="fv_sub_text">
                  信頼できる専門家による解説！
                </p>
              </div>
              <h1 class="fv_title">
                <span class="flex"><span class="border orange">税務</span><span class="t_green">/</span><span class="border green">登記</span><span class="t_green">/</span><span class="border blue">労務</span></span><br>
                <span class="dot">手</span><span class="dot">続</span><span class="dot">き</span>　なんでも　<br class="common_sp"><span class="wave_border">解説メディア</span>
              </h1>
              <a href="#top_search" class="fv_search_btn">
                さっそく記事を探す
                <img src="static/images/common/icon_menu_column_search.svg" alt="検索">
              </a>
            </div>
            <div class="fv_content_img">
              <img src="static/images/top/img_fv.svg" alt="">
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="common_layout_wrap">
      <div class="shere_menu_wrap top_shere">
        <p class="shere_menu_text">\ SHARE /</p>
        <ul class="shere_menu_list">
          <li class="shere_menu_item">
            <a href="#" class="shere_menu_link">
              <img src="static/images/common/icon_fb.svg" alt="facebook">
            </a>
          </li>
          <li class="shere_menu_item">
            <a href="#" class="shere_menu_link">
              <img src="static/images/common/icon_twitter.svg" alt="twitter">
            </a>
          </li>
          <li class="shere_menu_item">
            <a href="#" class="shere_menu_link">
              <img src="static/images/common/icon_insta.svg" alt="instagram">
            </a>
          </li>
          <li class="shere_menu_item">
            <a href="#" class="shere_menu_link">
              <img src="static/images/common/icon_line.svg" alt="LINE">
            </a>
          </li>
        </ul>
      </div>
      <div class="common_sova_banner_wrap top_banner">
        <div class="common_sova_banner_img">
          <img src="static/images/common/banner_sova.png" alt="バックオフィス　経理事務　ラクしたいなら！　sova　月額¥9,800〜（税込）　資料ダウンロード">
          <button type="button" name="button" class="common_sova_banner_close_btn">
            <img src="static/images/common/icon_ banner_close.svg" alt="×">
          </button>
        </div>
      </div>
      <div class="common_wrap">
        <div class="common_inner">
          <div class="common_layout_content">
            <div class="common_layout_main_wrap">
              <div class="common_layout_main_content_box">
                <section class="top_search" id="top_search">
                  <h2 class="common_title">
                    税務/登記/労務のカテゴリ一覧
                  </h2>
                  <div class="column_search_wrap">
                    <h3 class="column_search_title">
                      カテゴリ一覧
                    </h3>
                    <div class="column_search_block">
                      <ul class="column_search_large_category_list">
                        <li class="column_search_large_category_item">
                          <a href="column_list.html" class="column_search_large_category_item_title_link big_category01">
                            <span>大カテゴリ</span>
                          </a>
                          <ul class="column_search_category_list">
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category01">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category01">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category01">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category01">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category01">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category01">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category01">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category01">
                                中カテゴリ
                              </a>
                            </li>
                          </ul>
                        </li>
                        <li class="column_search_large_category_item">
                          <a href="column_list.html" class="column_search_large_category_item_title_link big_category02">
                            <span>大カテゴリ</span>
                          </a>
                          <ul class="column_search_category_list">
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category02">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category02">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category02">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category02">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category02">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category02">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category02">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category02">
                                中カテゴリ
                              </a>
                            </li>
                          </ul>
                        </li>
                        <li class="column_search_large_category_item">
                          <a href="column_list.html" class="column_search_large_category_item_title_link big_category03">
                            <span>大カテゴリ</span>
                          </a>
                          <ul class="column_search_category_list">
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category03">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category03">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category03">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category03">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category03">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category03">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category03">
                                中カテゴリ
                              </a>
                            </li>
                            <li class="column_search_category_item">
                              <a href="category.html" class="column_search_category_link category03">
                                中カテゴリ
                              </a>
                            </li>
                          </ul>
                        </li>
                      </ul>
                    </div>
                  </div>
                </section>
                <section class="top_pickup_column">
                  <h2 class="common_title">
                    ピックアップ記事
                  </h2>
                  <div class="pick_up_column_box_wrap">
                    <div class="pick_up_column_box">
                      <div class="pick_up_column_box_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                      </div>
                      <div class="pick_up_column_box_detail">
                        <h3 class="pick_up_column_box_title">
                          2023年から確定申告書Aが廃止に！個人事業主・会社員向けに書き方を解説
                        </h3>
                        <p class="pick_up_column_box_text">
                          2023年から確定申告書Aが廃止に！個事業主・会社員向けに書き方を解説2023年から確定申告書Aが廃止に！個人事業主・会社員向けに書き方を解説2023年から確定申告書Aが廃止に！個人事業主・会社員向けに書き方を解説
                        </p>
                        <div class="pick_up_column_box_update_release">
                          <p class="pick_up_column_box_update">
                            更新日：2023.05.10
                          </p>
                          <p class="pick_up_column_box_release">
                            公開日：2023.05.20
                          </p>
                        </div>
                      </div>
                      <a href="category.html" class="pick_up_column_box_category category02">
                        <span>中カテゴリ中カテゴリ中カテゴリ</span>
                      </a>
                      <a href="column_detail.html" class="pick_up_column_box_link"></a>
                    </div>
                    <div class="pick_up_column_box">
                      <div class="pick_up_column_box_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                      </div>
                      <div class="pick_up_column_box_detail">
                        <h3 class="pick_up_column_box_title">
                          2023年から確定申告書Aが廃止に！個人事業主・会社員向けに書き方を解説
                        </h3>
                        <p class="pick_up_column_box_text">
                          2023年から確定申告書Aが廃止に！個事業主・会社員向けに書き方を解説2023年から確定申告書Aが廃止に！個人事業主・会社員向けに書き方を解説2023年から確定申告書Aが廃止に！個人事業主・会社員向けに書き方を解説
                        </p>
                        <div class="pick_up_column_box_update_release">
                          <p class="pick_up_column_box_update">
                            更新日：2023.05.10
                          </p>
                          <p class="pick_up_column_box_release">
                            公開日：2023.05.20
                          </p>
                        </div>
                      </div>
                      <a href="category.html" class="pick_up_column_box_category category01">
                        <span>中カテゴリ</span>
                      </a>
                      <a href="column_detail.html" class="pick_up_column_box_link"></a>
                    </div>
                    <div class="pick_up_column_box">
                      <div class="pick_up_column_box_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                      </div>
                      <div class="pick_up_column_box_detail">
                        <h3 class="pick_up_column_box_title">
                          2023年から確定申告書Aが廃止に！個人事業主・会社員向けに書き方を解説
                        </h3>
                        <p class="pick_up_column_box_text">
                          2023年から確定申告書Aが廃止に！個事業主・会社員向けに書き方を解説2023年から確定申告書Aが廃止に！個人事業主・会社員向けに書き方を解説2023年から確定申告書Aが廃止に！個人事業主・会社員向けに書き方を解説
                        </p>
                        <div class="pick_up_column_box_update_release">
                          <p class="pick_up_column_box_update">
                            更新日：2023.05.10
                          </p>
                          <p class="pick_up_column_box_release">
                            公開日：2023.05.20
                          </p>
                        </div>
                      </div>
                      <a href="category.html" class="pick_up_column_box_category category03">
                        <span>中カテゴリ</span>
                      </a>
                      <a href="column_detail.html" class="pick_up_column_box_link"></a>
                    </div>
                  </div>
                </section>
                <section class="top_particulars">
                  <h2 class="common_title">
                    IDEMAEを始めた経緯
                  </h2>
                  <div class="top_particulars_chat_block_wrap">
                    <div class="top_particulars_chat_block left">
                      <div class="top_particulars_chat_left_icon">
                        <img src="static/images/column/icon_man01.svg" alt="">
                      </div>
                      <p class="top_particulars_chat_left_text">
                        <a href="#">バックオフィス</a>とは、企業内でお客様と直接関係する部署の人々が円滑に仕事を行なうことができるよう、様々な業務を行なう部門のことを指します。例えば、営業やカスタマーサポートといった部門で働く人た
                      </p>
                    </div>
                    <div class="top_particulars_chat_block right">
                      <p class="top_particulars_chat_right_text">
                        <a href="#">バックオフィス</a>とは、企業内でお客様と直接関係する部署の人々が円滑に仕事を行なうことができるよう、様々な業務を行なう部門のことを指します。例えば、営業やカスタマーサポートといった部門で働く人た
                      </p>
                      <div class="top_particulars_chat_right_icon">
                        <img src="static/images/column/icon_man02.svg" alt="">
                      </div>
                    </div>
                    <div class="top_particulars_chat_block left">
                      <div class="top_particulars_chat_left_icon">
                        <img src="static/images/column/icon_man01.svg" alt="">
                      </div>
                      <p class="top_particulars_chat_left_text">
                        <a href="#">バックオフィス</a>とは、企業内でお客様と直接関係する部署の人々が円滑に仕事を行なうことができるよう、様々な業務を行なう部門のことを指します。例えば、営業やカスタマーサポートといった部門で働く人た
                      </p>
                    </div>
                    <div class="top_particulars_chat_block right">
                      <p class="top_particulars_chat_right_text">
                        <a href="#">バックオフィス</a>とは、企業内でお客様と直接関係する部署の人々が円滑に仕事を行なうことができるよう、様々な業務を行なう部門のことを指します。例えば、営業やカスタマーサポートといった部門で働く人た
                      </p>
                      <div class="top_particulars_chat_right_icon">
                        <img src="static/images/column/icon_man02.svg" alt="">
                      </div>
                    </div>
                  </div>
                </section>
                <section class="top_new_column">
                  <h2 class="common_title">
                    新着記事
                  </h2>
                  <div class="column_box_wrap">
                    <div class="column_box">
                      <a href="category.html" class="column_box_category category01">
                        <span>中カテゴリ中カテゴリ中カテゴリ中カテゴリ</span>
                      </a>
                      <a href="column_detail.html" class="column_box_link">
                        <p class="column_box_date">
                          2023.05.10
                        </p>
                        <div class="column_box_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                          <div class="column_box_new">
                            <img src="static/images/common/icon_new.svg" alt="NEW">
                          </div>
                        </div>
                        <h3 class="column_box_title">
                          役員報酬の適正額はいくら？決めるときの注意役員報酬の適正額はいくら？決めるときの注意
                        </h3>
                        <p class="column_box_text">
                          確定申告のやり方はこんな感じです分かりますか分かりますかワカますかワカ確定申告のやり方はこんな感じです分かりますか分かりますかワカますかワカ
                        </p>
                      </a>
                      <ul class="column_box_tag_list">
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div class="column_box">
                      <a href="category.html" class="column_box_category category02">
                        <span>中カテゴリ</span>
                      </a>
                      <a href="column_detail.html" class="column_box_link">
                        <p class="column_box_date">
                          2023.05.10
                        </p>
                        <div class="column_box_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                          <div class="column_box_new">
                            <img src="static/images/common/icon_new.svg" alt="NEW">
                          </div>
                        </div>
                        <h3 class="column_box_title">
                          役員報酬の適正額はいくら？決めるときの注意役員報酬の適正額はいくら？決めるときの注意
                        </h3>
                        <p class="column_box_text">
                          確定申告のやり方はこんな感じです分かりますか分かりますかワカますかワカ確定申告のやり方はこんな感じです分かりますか分かりますかワカますかワカ
                        </p>
                      </a>
                      <ul class="column_box_tag_list">
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div class="column_box">
                      <a href="category.html" class="column_box_category category01">
                        <span>中カテゴリ</span>
                      </a>
                      <a href="column_detail.html" class="column_box_link">
                        <p class="column_box_date">
                          2023.05.10
                        </p>
                        <div class="column_box_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                          <div class="column_box_new">
                            <img src="static/images/common/icon_new.svg" alt="NEW">
                          </div>
                        </div>
                        <h3 class="column_box_title">
                          役員報酬の適正額はいくら？決めるときの注意役員報酬の適正額はいくら？決めるときの注意
                        </h3>
                        <p class="column_box_text">
                          確定申告のやり方はこんな感じです分かりますか分かりますかワカますかワカ確定申告のやり方はこんな感じです分かりますか分かりますかワカますかワカ
                        </p>
                      </a>
                      <ul class="column_box_tag_list">
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div class="column_box">
                      <a href="category.html" class="column_box_category category03">
                        <span>中カテゴリ</span>
                      </a>
                      <a href="column_detail.html" class="column_box_link">
                        <p class="column_box_date">
                          2023.05.10
                        </p>
                        <div class="column_box_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                          <div class="column_box_new">
                            <img src="static/images/common/icon_new.svg" alt="NEW">
                          </div>
                        </div>
                        <h3 class="column_box_title">
                          役員報酬の適正額はいくら？決めるときの注意役員報酬の適正額はいくら？決めるときの注意
                        </h3>
                        <p class="column_box_text">
                          確定申告のやり方はこんな感じです分かりますか分かりますかワカますかワカ確定申告のやり方はこんな感じです分かりますか分かりますかワカますかワカ
                        </p>
                      </a>
                      <ul class="column_box_tag_list">
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div class="column_box">
                      <a href="category.html" class="column_box_category category01">
                        <span>中カテゴリ</span>
                      </a>
                      <a href="column_detail.html" class="column_box_link">
                        <p class="column_box_date">
                          2023.05.10
                        </p>
                        <div class="column_box_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                          <div class="column_box_new">
                            <img src="static/images/common/icon_new.svg" alt="NEW">
                          </div>
                        </div>
                        <h3 class="column_box_title">
                          役員報酬の適正額はいくら？決めるときの注意役員報酬の適正額はいくら？決めるときの注意
                        </h3>
                        <p class="column_box_text">
                          確定申告のやり方はこんな感じです分かりますか分かりますかワカますかワカ確定申告のやり方はこんな感じです分かりますか分かりますかワカますかワカ
                        </p>
                      </a>
                      <ul class="column_box_tag_list">
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                      </ul>
                    </div>
                    <div class="column_box">
                      <a href="category.html" class="column_box_category category01">
                        <span>中カテゴリ</span>
                      </a>
                      <a href="column_detail.html" class="column_box_link">
                        <p class="column_box_date">
                          2023.05.10
                        </p>
                        <div class="column_box_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                          <div class="column_box_new">
                            <img src="static/images/common/icon_new.svg" alt="NEW">
                          </div>
                        </div>
                        <h3 class="column_box_title">
                          役員報酬の適正額はいくら？決めるときの注意役員報酬の適正額はいくら？決めるときの注意
                        </h3>
                        <p class="column_box_text">
                          確定申告のやり方はこんな感じです分かりますか分かりますかワカますかワカ確定申告のやり方はこんな感じです分かりますか分かりますかワカますかワカ
                        </p>
                      </a>
                      <ul class="column_box_tag_list">
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                        <li class="column_box_tag_item">
                          <a href="category.html#tag01" class="category_tag_link">
                            タグタグ
                          </a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </section>
              </div>
            </div>
            <div class="common_layout_side_wrap">
              <section class="common_column_recommend">
                <h2 class="common_layout_side_title">
                  おすすめ記事一覧
                </h2>
                <ul class="common_side_column_list">
                  <li class="common_side_column_item">
                    <div class="common_side_column_item_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                      <div class="common_side_column_item_new">
                        <img src="static/images/common/icon_new.svg" alt="NEW">
                      </div>
                    </div>
                    <div class="common_side_column_item_detail">
                      <h3 class="common_side_column_item_title">
                        【今さら聞けない？】バックオフィスとは？効率化する方法【今さら聞けない？】バックオフィスとは？効率化する方法
                      </h3>
                      <p class="common_side_column_item_text">
                        確定申告のやり方です確定申告のやり方です確定申告のやり方です確定申告のやり方確定申告のやり方です確定申告のやり方です確定申告のやり方です確定申告のやり方
                      </p>
                      <p class="common_side_column_item_date">
                        2023.05.03
                      </p>
                    </div>
                    <a href="category.html" class="common_side_column_item_category category01">
                      <span>中カテゴリ中カテゴリ中カテゴリ中カテゴリ</span>
                    </a>
                    <a href="column_detail.html" class="common_side_column_item_link"></a>
                  </li>
                  <li class="common_side_column_item">
                    <div class="common_side_column_item_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                      <div class="common_side_column_item_new">
                        <img src="static/images/common/icon_new.svg" alt="NEW">
                      </div>
                    </div>
                    <div class="common_side_column_item_detail">
                      <h3 class="common_side_column_item_title">
                        【今さら聞けない？】バックオフィスとは？効率化する方法【今さら聞けない？】バックオフィスとは？効率化する方法
                      </h3>
                      <p class="common_side_column_item_text">
                        確定申告のやり方です確定申告のやり方です確定申告のやり方です確定申告のやり方確定申告のやり方です確定申告のやり方です確定申告のやり方です確定申告のやり方
                      </p>
                      <p class="common_side_column_item_date">
                        2023.05.03
                      </p>
                    </div>
                    <a href="category.html" class="common_side_column_item_category category01">
                      <span>中カテゴリ</span>
                    </a>
                    <a href="column_detail.html" class="common_side_column_item_link"></a>
                  </li>
                  <li class="common_side_column_item">
                    <div class="common_side_column_item_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                      <div class="common_side_column_item_new">
                        <img src="static/images/common/icon_new.svg" alt="NEW">
                      </div>
                    </div>
                    <div class="common_side_column_item_detail">
                      <h3 class="common_side_column_item_title">
                        【今さら聞けない？】バックオフィスとは？効率化する方法【今さら聞けない？】バックオフィスとは？効率化する方法
                      </h3>
                      <p class="common_side_column_item_text">
                        確定申告のやり方です確定申告のやり方です確定申告のやり方です確定申告のやり方確定申告のやり方です確定申告のやり方です確定申告のやり方です確定申告のやり方
                      </p>
                      <p class="common_side_column_item_date">
                        2023.05.03
                      </p>
                    </div>
                    <a href="category.html" class="common_side_column_item_category category01">
                      <span>中カテゴリ</span>
                    </a>
                    <a href="column_detail.html" class="common_side_column_item_link"></a>
                  </li>
                  <li class="common_side_column_item">
                    <div class="common_side_column_item_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                      <div class="common_side_column_item_new">
                        <img src="static/images/common/icon_new.svg" alt="NEW">
                      </div>
                    </div>
                    <div class="common_side_column_item_detail">
                      <h3 class="common_side_column_item_title">
                        【今さら聞けない？】バックオフィスとは？効率化する方法【今さら聞けない？】バックオフィスとは？効率化する方法
                      </h3>
                      <p class="common_side_column_item_text">
                        確定申告のやり方です確定申告のやり方です確定申告のやり方です確定申告のやり方確定申告のやり方です確定申告のやり方です確定申告のやり方です確定申告のやり方
                      </p>
                      <p class="common_side_column_item_date">
                        2023.05.03
                      </p>
                    </div>
                    <a href="category.html" class="common_side_column_item_category category01">
                      <span>中カテゴリ</span>
                    </a>
                    <a href="column_detail.html" class="common_side_column_item_link"></a>
                  </li>
                </ul>
              </section>
              <section class="common_relation_site">
                <h2 class="common_layout_side_title">
                  参考リンク
                </h2>
                <ul class="relation_site_list">
                  <li class="relation_site_item">
                    <a href="#" class="relation_site_link">
                      <div class="relation_site_link_img">
                        <img src="static/images/sample/img_sample_logo.png" alt="">
                      </div>
                      <div class="relation_site_link_detail">
                        <h3 class="relation_site_link_title">
                          サイト名サイト名
                        </h3>
                        <p class="relation_site_link_text">
                          サイトの説明サイトの説明サイトの説明サイトの説明サイトの説明サイトの説明サイトの説明
                        </p>
                      </div>
                    </a>
                  </li>
                  <li class="relation_site_item">
                    <a href="#" class="relation_site_link">
                      <div class="relation_site_link_img">
                        <img src="static/images/sample/img_sample_logo.png" alt="">
                      </div>
                      <div class="relation_site_link_detail">
                        <h3 class="relation_site_link_title">
                          サイト名サイト名
                        </h3>
                        <p class="relation_site_link_text">
                          サイトの説明サイトの説明サイトの説明サイトの説明サイトの説明サイトの説明サイトの説明
                        </p>
                      </div>
                    </a>
                  </li>
                  <li class="relation_site_item">
                    <a href="#" class="relation_site_link">
                      <div class="relation_site_link_img">
                        <img src="static/images/sample/img_sample_logo.png" alt="">
                      </div>
                      <div class="relation_site_link_detail">
                        <h3 class="relation_site_link_title">
                          サイト名サイト名
                        </h3>
                        <p class="relation_site_link_text">
                          サイトの説明サイトの説明サイトの説明サイトの説明サイトの説明サイトの説明サイトの説明
                        </p>
                      </div>
                    </a>
                  </li>
                </ul>
              </section>
              <section class="common_column_new">
                <h2 class="common_layout_side_title">
                  新着記事
                </h2>
                <ul class="common_side_new_column_list">
                  <li class="common_side_new_column_item">
                    <a href="column_detail.html" class="common_side_new_column_item_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                      <div class="common_side_new_column_item_new">
                        <img src="static/images/common/icon_new.svg" alt="NEW">
                      </div>
                    </a>
                    <div class="common_side_new_column_item_detail">
                      <a href="column_detail.html" class="common_side_new_column_item_title_link">
                        <h3 class="common_side_new_column_item_title">
                          【今さら聞けない？】バックオフィスとは？効率化する方法【今さら聞けない？】バックオフィスとは？効率化する方法
                        </h3>
                      </a>
                      <div class="common_side_new_column_item_category_date">
                        <a href="category.html" class="common_side_new_column_item_category category01">
                          <span>中カテゴリ</span>
                        </a>
                        <a href="column_detail.html" class="common_side_new_column_item_date">
                          2023.05.03
                        </a>
                      </div>
                    </div>
                  </li>
                  <li class="common_side_new_column_item">
                    <a href="column_detail.html" class="common_side_new_column_item_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                      <div class="common_side_new_column_item_new">
                        <img src="static/images/common/icon_new.svg" alt="NEW">
                      </div>
                    </a>
                    <div class="common_side_new_column_item_detail">
                      <a href="column_detail.html" class="common_side_new_column_item_title_link">
                        <h3 class="common_side_new_column_item_title">
                          【今さら聞けない？】バックオフィスとは？効率化する方法【今さら聞けない？】バックオフィスとは？効率化する方法
                        </h3>
                      </a>
                      <div class="common_side_new_column_item_category_date">
                        <a href="category.html" class="common_side_new_column_item_category category01">
                          <span>中カテゴリ</span>
                        </a>
                        <a href="column_detail.html" class="common_side_new_column_item_date">
                          2023.05.03
                        </a>
                      </div>
                    </div>
                  </li>
                  <li class="common_side_new_column_item">
                    <a href="column_detail.html" class="common_side_new_column_item_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                      <div class="common_side_new_column_item_new">
                        <img src="static/images/common/icon_new.svg" alt="NEW">
                      </div>
                    </a>
                    <div class="common_side_new_column_item_detail">
                      <a href="column_detail.html" class="common_side_new_column_item_title_link">
                        <h3 class="common_side_new_column_item_title">
                          【今さら聞けない？】バックオフィスとは？効率化する方法【今さら聞けない？】バックオフィスとは？効率化する方法
                        </h3>
                      </a>
                      <div class="common_side_new_column_item_category_date">
                        <a href="category.html" class="common_side_new_column_item_category category01">
                          <span>中カテゴリ</span>
                        </a>
                        <a href="column_detail.html" class="common_side_new_column_item_date">
                          2023.05.03
                        </a>
                      </div>
                    </div>
                  </li>
                  <li class="common_side_new_column_item">
                    <a href="column_detail.html" class="common_side_new_column_item_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                      <div class="common_side_new_column_item_new">
                        <img src="static/images/common/icon_new.svg" alt="NEW">
                      </div>
                    </a>
                    <div class="common_side_new_column_item_detail">
                      <a href="column_detail.html" class="common_side_new_column_item_title_link">
                        <h3 class="common_side_new_column_item_title">
                          【今さら聞けない？】バックオフィスとは？効率化する方法【今さら聞けない？】バックオフィスとは？効率化する方法
                        </h3>
                      </a>
                      <div class="common_side_new_column_item_category_date">
                        <a href="category.html" class="common_side_new_column_item_category category01">
                          <span>中カテゴリ</span>
                        </a>
                        <a href="column_detail.html" class="common_side_new_column_item_date">
                          2023.05.03
                        </a>
                      </div>
                    </div>
                  </li>
                </ul>
              </section>
              <section class="common_side_press_release">
                <h2 class="common_layout_side_title">
                  SoVaのプレスリリース
                </h2>
                <ul class="common_side_press_release_list">
                  <li class="common_side_press_release_item">
                    <a href="#" class="common_side_press_release_link">
                      <div class="common_side_press_release_item_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                      </div>
                      <h3 class="common_side_press_release_item_title">
                        チャットAIに関する特許出願を完了チャットAIに関する特許出願を完了チャットAIに関する特許出願を完了
                      </h3>
                      <p class="common_side_press_release_item_date">
                        2023.05.19
                      </p>
                    </a>
                  </li>
                  <li class="common_side_press_release_item">
                    <a href="#" class="common_side_press_release_link">
                      <div class="common_side_press_release_item_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                      </div>
                      <h3 class="common_side_press_release_item_title">
                        チャットAIに関する特許出願を完了チャットAIに関する特許出願を完了チャットAIに関する特許出願を完了
                      </h3>
                      <p class="common_side_press_release_item_date">
                        2023.05.19
                      </p>
                    </a>
                  </li>
                  <li class="common_side_press_release_item">
                    <a href="#" class="common_side_press_release_link">
                      <div class="common_side_press_release_item_img" style="background-image:url(static/images/sample/img_sample01.jpg);">
                      </div>
                      <h3 class="common_side_press_release_item_title">
                        チャットAIに関する特許出願を完了チャットAIに関する特許出願を完了チャットAIに関する特許出願を完了
                      </h3>
                      <p class="common_side_press_release_item_date">
                        2023.05.19
                      </p>
                    </a>
                  </li>
                </ul>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>
  <footer>
    <?php require_once('footer.html'); ?>
  </footer>
  <script type="text/javascript" src="static/js/common.js">
  </script>
</body>
</html>
