<!DOCTYPE HTML>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
    <title>About</title>
  </head>
  <body>
    <header>
      <?php require_once('header.php'); ?>
    </header>
    <main>
      <?php require_once('main.php'); ?>
    </main>
    <footer>
      <?php require_once('footer.php'); ?>
    </footer>
  </body>
<html>
