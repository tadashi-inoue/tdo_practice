<?php
function get_header() {
  require_once('header.php');
}
function get_footer() {
  require_once('footer.php');
}
?>
